Alexander Mihailov, 10 October 2024

This is the readme_GPS241010.txt file for the replication of "Greening Prosperity Stripes across the Globe", Discussion Paper 2023-17 (November 2023, revised in April and, then, September 2024) at the Department of Economics, University of Reading.

All data sources and links to the data are from the World Bank and provided in the paper (with respective URLs). There are also dat Ian the public domain from the UK Met Office, also provided in the paper (with respective URLs)

There are 2 subfolders:

   STATASE18 -> This folder contains data and STATA (version SE 18) codes in a zip archive, WBMapGPS_replicationSTATA_NoShpNoFigs.zip. It is the same as the repository called GreeningProsperityStripes_WorldMapsEcsObs24_replication, and it contains a separate readme file, readme_WBMapGPS_replication.pdf. This folder generates the world maps, without winsorizing as well as with winsorizing

   MATLABR2023a -> This folder contains data and MATLAB (version R2023a) codes in a zip archive, GreeningProsperityStripes_RevDPSep24_replicationMATLABNoFigs.zip. Its content is described below. It generates the various greening prosperity stripes.

In particular, there are 3 original *.xls files downloaded from the World Bank database online:

API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xls -> World Bank CO2 emissions data API_NY.GDP.PCAP.CD_DS2_en_excel_v2_5607109.xls -> World Bank GDP pc data in USD of 2015 API_NY.GDP.PCAP.PP.KD_DS2_en_excel_v2_5607670.xls -> World Bank GDP pc data at PPP in international USD of 2017

There are 3 corresponding *.xlsx files with the same name, containing some minimal notes, marks and manipulations by me that were used for all 10 codes herein: note that MATLAB in Mac OS allows only working with *.xlsx files, not *.xls ones, so I had created the former from the latter:

API_EN.ATM.CO2E.PC_DS2_en_excel_v2_5607813.xlsx
API_NY.GDP.PCAP.CD_DS2_en_excel_v2_5607109.xlsx
API_NY.GDP.PCAP.PP.KD_DS2_en_excel_v2_5607670.xlsx

The 10 MATLAB code (*.m) files described below can be executed in arbitrary order. The first 7 use the above *.xlsx files to read from.

GDPpcCO2pcStripes1stSmpl4Groups8Countries_am231204.m
GDPpcCO2pcStripes2ndSmpl2Groups10Countries_am231204.m

GDPpcCO2pcStripes1stSmpl4Groups8CountriesMinMaxWorld_am241010.m 
GDPpcCO2pcStripes2ndSmpl2Groups10CountriesMinMaxWorld_am241010.m

GDPpcCO2pcStripes1stSmpl4Groups8CountriesMinMaxWorld_am241007w5.m -> with winsorization at %5 and 95% as in the cross-section for 2020 (I.e., comparable with the respective winsorization in the STATASE18 folder)
GDPpcCO2pcStripes2ndSmpl2Groups10CountriesMinMaxWorld_am241007w5.m -> with winsorization at %5 and 95% as in the cross-section for 2020 (I.e., comparable with the respective winsorization in the STATASE18 folder)

GDPpcCO2pcStripesWorldCrossSectionByYear_am231204.m -> for 4 cross-sections: 1990, 2000, 2010 and 2020

The next 2 *.m codes,

GDPpcWorldUSDof2015Stripes_am231204.m
LifeExpectancyWorldStripes_am231204.m

use 2 *.txt files to read from (based, again, on the World Bank original data), namely,

GDPpcWorldUSDof2015.txt
LifeExpectancyWorld.txt

Finally,

ClimateStripesReplication.m

uses the Met Office HadCRUT.5.0.1.0.analysis.summary_series.global.annual.txt data to replicate the climate stripes.

The filenames of the *.m programs are self-explanatory. Each of them contains very detailed annotation and guidance.

The MATLAB R2023a programs generate all graphs for the figures in the paper, as well as the necessary ingredients to compile (manually) Table 1.